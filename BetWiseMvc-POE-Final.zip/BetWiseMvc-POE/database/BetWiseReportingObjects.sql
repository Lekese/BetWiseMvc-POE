/*
    BetWise MVC POE database evidence script.
    Entity Framework Core migrations create the same view and indexes.
    Run this script only when demonstrating the SQL objects manually.
*/

CREATE OR ALTER VIEW dbo.vw_UserAccountSummary
AS
SELECT
    u.Id AS UserId,
    u.IDNumber,
    u.FirstName,
    u.Surname,
    u.Email,
    u.PhoneNumber,
    COUNT(a.Id) AS AccountCount,
    SUM(CASE WHEN a.Status = 'Open' THEN 1 ELSE 0 END) AS OpenAccountCount,
    SUM(CASE WHEN a.Status = 'Closed' THEN 1 ELSE 0 END) AS ClosedAccountCount,
    COALESCE(SUM(a.Balance), 0) AS TotalBalance,
    STRING_AGG(a.AccountNumber, ', ') AS AccountNumbers
FROM dbo.Users AS u
LEFT JOIN dbo.BettingAccounts AS a
    ON u.Id = a.UserId
GROUP BY
    u.Id,
    u.IDNumber,
    u.FirstName,
    u.Surname,
    u.Email,
    u.PhoneNumber;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_BetTransactions_TransactionDate'
      AND object_id = OBJECT_ID('dbo.BetTransactions')
)
BEGIN
    CREATE INDEX IX_BetTransactions_TransactionDate
        ON dbo.BetTransactions (TransactionDate);
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_BettingAccounts_Status'
      AND object_id = OBJECT_ID('dbo.BettingAccounts')
)
BEGIN
    CREATE INDEX IX_BettingAccounts_Status
        ON dbo.BettingAccounts (Status);
END;
GO
