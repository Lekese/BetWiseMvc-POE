using System.Globalization;
using BetWiseMvc.Data;
using BetWiseMvc.Services;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            var southAfricanCulture = new CultureInfo("en-ZA");
            CultureInfo.DefaultThreadCurrentCulture = southAfricanCulture;
            CultureInfo.DefaultThreadCurrentUICulture = southAfricanCulture;

            builder.Services.AddControllersWithViews();

            builder.Services.AddDbContext<ApplicationDbContext>(options =>
            {
                var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
                options.UseSqlServer(connectionString);
            });

            builder.Services.AddScoped<UserService>();
            builder.Services.AddScoped<AccountService>();
            builder.Services.AddScoped<BetService>();
            builder.Services.AddScoped<ReportService>();

            var app = builder.Build();

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();

            if (app.Environment.IsDevelopment())
            {
                using var scope = app.Services.CreateScope();
                var database = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                database.Database.Migrate();
            }

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
