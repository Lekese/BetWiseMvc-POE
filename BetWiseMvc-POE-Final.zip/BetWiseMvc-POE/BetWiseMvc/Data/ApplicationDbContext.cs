using BetWiseMvc.Models;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }

        public DbSet<BettingAccount> BettingAccounts { get; set; }

        public DbSet<BetTransaction> BetTransactions { get; set; }

        public DbSet<UserAccountSummary> UserAccountSummaries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasIndex(u => u.IDNumber)
                .IsUnique();

            modelBuilder.Entity<BettingAccount>()
                .HasIndex(a => a.AccountNumber)
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasMany(u => u.BettingAccounts)
                .WithOne(a => a.User)
                .HasForeignKey(a => a.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<BettingAccount>()
                .HasMany(a => a.BetTransactions)
                .WithOne(t => t.BettingAccount)
                .HasForeignKey(t => t.BettingAccountId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<UserAccountSummary>()
                .HasNoKey()
                .ToView("vw_UserAccountSummary");
        }
    }
}