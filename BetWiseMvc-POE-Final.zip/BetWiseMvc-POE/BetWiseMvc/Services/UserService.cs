using BetWiseMvc.Data;
using BetWiseMvc.Models;
using BetWiseMvc.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Services
{
    public class UserService
    {
        private readonly ApplicationDbContext context;
        private readonly int pageSize = 10;

        public UserService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public UserListViewModel GetUsers(string? search, int pageIndex)
        {
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }

            IQueryable<User> query = context.Users
                .Include(u => u.BettingAccounts);

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(u =>
                    u.IDNumber.Contains(search) ||
                    u.Surname.Contains(search) ||
                    u.BettingAccounts.Any(a => a.AccountNumber.Contains(search)));
            }

            int totalRecords = query.Count();
            int totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

            List<User> users = query
                .OrderByDescending(u => u.Id)
                .Skip((pageIndex - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            return new UserListViewModel
            {
                Users = users,
                Search = search ?? "",
                PageIndex = pageIndex,
                TotalPages = totalPages
            };
        }

        public User? GetUserById(int id)
        {
            return context.Users
                .Include(u => u.BettingAccounts)
                .FirstOrDefault(u => u.Id == id);
        }

        public string CreateUser(UserDto userDto)
        {
            string idNumber = userDto.IDNumber.Trim();

            bool idNumberExists = context.Users
                .Any(u => u.IDNumber == idNumber);

            if (idNumberExists)
            {
                return "A user with this ID Number already exists.";
            }

            User user = new User
            {
                IDNumber = idNumber,
                FirstName = userDto.FirstName.Trim(),
                Surname = userDto.Surname.Trim(),
                Email = string.IsNullOrWhiteSpace(userDto.Email) ? null : userDto.Email.Trim(),
                PhoneNumber = string.IsNullOrWhiteSpace(userDto.PhoneNumber) ? null : userDto.PhoneNumber.Trim(),
                CreatedAt = DateTime.Now
            };

            context.Users.Add(user);
            context.SaveChanges();

            return "";
        }

        public string UpdateUser(int id, UserDto userDto)
        {
            User? user = context.Users.Find(id);

            if (user == null)
            {
                return "User not found.";
            }

            string idNumber = userDto.IDNumber.Trim();

            bool idNumberExists = context.Users
                .Any(u => u.IDNumber == idNumber && u.Id != id);

            if (idNumberExists)
            {
                return "Another user with this ID Number already exists.";
            }

            user.IDNumber = idNumber;
            user.FirstName = userDto.FirstName.Trim();
            user.Surname = userDto.Surname.Trim();
            user.Email = string.IsNullOrWhiteSpace(userDto.Email) ? null : userDto.Email.Trim();
            user.PhoneNumber = string.IsNullOrWhiteSpace(userDto.PhoneNumber) ? null : userDto.PhoneNumber.Trim();
            user.UpdatedAt = DateTime.Now;

            context.Users.Update(user);
            context.SaveChanges();

            return "";
        }

        public string DeleteUser(int id)
        {
            User? user = context.Users
                .Include(u => u.BettingAccounts)
                .ThenInclude(a => a.BetTransactions)
                .FirstOrDefault(u => u.Id == id);

            if (user == null)
            {
                return "User not found.";
            }

            bool hasOpenAccounts = user.BettingAccounts
                .Any(a => a.Status == "Open");

            if (hasOpenAccounts)
            {
                return "This user cannot be deleted because they still have open betting accounts.";
            }

            foreach (var account in user.BettingAccounts)
            {
                context.BetTransactions.RemoveRange(account.BetTransactions);
            }

            context.BettingAccounts.RemoveRange(user.BettingAccounts);
            context.Users.Remove(user);

            context.SaveChanges();

            return "";
        }

        public UserDto ConvertToDto(User user)
        {
            return new UserDto
            {
                IDNumber = user.IDNumber,
                FirstName = user.FirstName,
                Surname = user.Surname,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber
            };
        }
    }
}