using BetWiseMvc.Data;
using BetWiseMvc.Models;
using BetWiseMvc.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Services
{
    public class AccountService
    {
        private readonly ApplicationDbContext context;

        public AccountService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public User? GetUserById(int userId)
        {
            return context.Users.Find(userId);
        }

        public BettingAccount? GetAccountById(int id)
        {
            return context.BettingAccounts
                .Include(a => a.User)
                .Include(a => a.BetTransactions)
                .FirstOrDefault(a => a.Id == id);
        }

        public string CreateAccount(int userId, AccountDto accountDto)
        {
            User? user = context.Users.Find(userId);

            if (user == null)
            {
                return "User not found. An account can only be created after the user has been created.";
            }

            string accountNumber = accountDto.AccountNumber.Trim();

            bool accountNumberExists = context.BettingAccounts
                .Any(a => a.AccountNumber == accountNumber);

            if (accountNumberExists)
            {
                return "An account with this account number already exists.";
            }

            BettingAccount account = new BettingAccount
            {
                UserId = userId,
                AccountNumber = accountNumber,
                Balance = 0,
                Status = "Open",
                CreatedAt = DateTime.Now
            };

            context.BettingAccounts.Add(account);
            context.SaveChanges();

            return "";
        }

        public string UpdateAccount(int id, AccountDto accountDto)
        {
            BettingAccount? account = context.BettingAccounts.Find(id);

            if (account == null)
            {
                return "Account not found.";
            }

            string accountNumber = accountDto.AccountNumber.Trim();

            bool accountNumberExists = context.BettingAccounts
                .Any(a => a.AccountNumber == accountNumber && a.Id != id);

            if (accountNumberExists)
            {
                return "Another account with this account number already exists.";
            }

            account.AccountNumber = accountNumber;
            account.UpdatedAt = DateTime.Now;

            context.BettingAccounts.Update(account);
            context.SaveChanges();

            return "";
        }

        public string CloseAccount(int id)
        {
            BettingAccount? account = context.BettingAccounts.Find(id);

            if (account == null)
            {
                return "Account not found.";
            }

            if (account.Status == "Closed")
            {
                return "This account is already closed.";
            }

            if (account.Balance != 0)
            {
                return "This account cannot be closed because the balance is not zero.";
            }

            account.Status = "Closed";
            account.UpdatedAt = DateTime.Now;

            context.BettingAccounts.Update(account);
            context.SaveChanges();

            return "";
        }

        public string ReopenAccount(int id)
        {
            BettingAccount? account = context.BettingAccounts.Find(id);

            if (account == null)
            {
                return "Account not found.";
            }

            if (account.Status == "Open")
            {
                return "This account is already open.";
            }

            account.Status = "Open";
            account.UpdatedAt = DateTime.Now;

            context.BettingAccounts.Update(account);
            context.SaveChanges();

            return "";
        }

        public AccountDto ConvertToDto(BettingAccount account)
        {
            return new AccountDto
            {
                AccountNumber = account.AccountNumber
            };
        }
    }
}