using BetWiseMvc.Data;
using BetWiseMvc.Models;
using BetWiseMvc.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Services
{
    public class BetService
    {
        private readonly ApplicationDbContext context;

        public BetService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public BettingAccount? GetAccountById(int accountId)
        {
            return context.BettingAccounts
                .Include(a => a.User)
                .Include(a => a.BetTransactions)
                .FirstOrDefault(a => a.Id == accountId);
        }

        public BetTransaction? GetTransactionById(int id)
        {
            return context.BetTransactions
                .Include(t => t.BettingAccount)
                .ThenInclude(a => a!.User)
                .FirstOrDefault(t => t.Id == id);
        }

        public string CreateTransaction(int accountId, BetTransactionDto transactionDto)
        {
            BettingAccount? account = context.BettingAccounts.Find(accountId);

            if (account == null)
            {
                return "Account not found. A transaction can only be added after the account has been created.";
            }

            if (account.Status == "Closed")
            {
                return "No transactions may be posted to a closed account.";
            }

            string validationMessage = ValidateTransaction(transactionDto);

            if (!string.IsNullOrWhiteSpace(validationMessage))
            {
                return validationMessage;
            }

            BetTransaction transaction = new BetTransaction
            {
                BettingAccountId = accountId,
                TransactionDate = transactionDto.TransactionDate,
                CaptureDate = DateTime.Now,
                TransactionType = transactionDto.TransactionType,
                Amount = transactionDto.Amount,
                Description = string.IsNullOrWhiteSpace(transactionDto.Description) ? null : transactionDto.Description.Trim()
            };

            ApplyTransactionToBalance(account, transaction.TransactionType, transaction.Amount);

            context.BetTransactions.Add(transaction);
            context.BettingAccounts.Update(account);
            context.SaveChanges();

            return "";
        }

        public string UpdateTransaction(int id, BetTransactionDto transactionDto)
        {
            BetTransaction? transaction = context.BetTransactions
                .Include(t => t.BettingAccount)
                .FirstOrDefault(t => t.Id == id);

            if (transaction == null)
            {
                return "Transaction not found.";
            }

            BettingAccount? account = transaction.BettingAccount;

            if (account == null)
            {
                return "Linked account not found.";
            }

            if (account.Status == "Closed")
            {
                return "Transactions cannot be edited on a closed account.";
            }

            string validationMessage = ValidateTransaction(transactionDto);

            if (!string.IsNullOrWhiteSpace(validationMessage))
            {
                return validationMessage;
            }

            ReverseTransactionFromBalance(account, transaction.TransactionType, transaction.Amount);

            transaction.TransactionDate = transactionDto.TransactionDate;
            transaction.CaptureDate = DateTime.Now;
            transaction.TransactionType = transactionDto.TransactionType;
            transaction.Amount = transactionDto.Amount;
            transaction.Description = string.IsNullOrWhiteSpace(transactionDto.Description) ? null : transactionDto.Description.Trim();

            ApplyTransactionToBalance(account, transaction.TransactionType, transaction.Amount);

            context.BetTransactions.Update(transaction);
            context.BettingAccounts.Update(account);
            context.SaveChanges();

            return "";
        }

        public BetTransactionDto ConvertToDto(BetTransaction transaction)
        {
            return new BetTransactionDto
            {
                TransactionDate = transaction.TransactionDate,
                TransactionType = transaction.TransactionType,
                Amount = transaction.Amount,
                Description = transaction.Description
            };
        }

        private string ValidateTransaction(BetTransactionDto transactionDto)
        {
            if (transactionDto.TransactionDate.Date > DateTime.Today)
            {
                return "The transaction date cannot be in the future.";
            }

            if (transactionDto.Amount <= 0)
            {
                return "The transaction amount must be greater than zero.";
            }

            if (transactionDto.TransactionType != "Debit" && transactionDto.TransactionType != "Credit")
            {
                return "Transaction type must be Debit or Credit.";
            }

            return "";
        }

        private void ApplyTransactionToBalance(BettingAccount account, string transactionType, decimal amount)
        {
            if (transactionType == "Credit")
            {
                account.Balance += amount;
            }
            else if (transactionType == "Debit")
            {
                account.Balance -= amount;
            }

            account.UpdatedAt = DateTime.Now;
        }

        private void ReverseTransactionFromBalance(BettingAccount account, string transactionType, decimal amount)
        {
            if (transactionType == "Credit")
            {
                account.Balance -= amount;
            }
            else if (transactionType == "Debit")
            {
                account.Balance += amount;
            }

            account.UpdatedAt = DateTime.Now;
        }
    }
}