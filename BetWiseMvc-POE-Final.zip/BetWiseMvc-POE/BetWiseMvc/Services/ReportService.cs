using BetWiseMvc.Data;
using BetWiseMvc.Models;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Services
{
    public class ReportService
    {
        private readonly ApplicationDbContext context;

        public ReportService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public List<UserAccountSummary> GetUserAccountSummaries(string? search)
        {
            IQueryable<UserAccountSummary> query = context.UserAccountSummaries
                .AsNoTracking();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string searchValue = search.Trim();

                query = query.Where(summary =>
                    summary.IDNumber.Contains(searchValue) ||
                    summary.Surname.Contains(searchValue) ||
                    (summary.AccountNumbers != null && summary.AccountNumbers.Contains(searchValue)));
            }

            return query
                .OrderBy(summary => summary.Surname)
                .ThenBy(summary => summary.FirstName)
                .ToList();
        }
    }
}
