using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Models
{
    [Keyless]
    public class UserAccountSummary
    {
        public int UserId { get; set; }

        public string IDNumber { get; set; } = "";

        public string FirstName { get; set; } = "";

        public string Surname { get; set; } = "";

        public string? Email { get; set; }

        public string? PhoneNumber { get; set; }

        public int AccountCount { get; set; }

        public int OpenAccountCount { get; set; }

        public int ClosedAccountCount { get; set; }

        public decimal TotalBalance { get; set; }

        public string? AccountNumbers { get; set; }
    }
}