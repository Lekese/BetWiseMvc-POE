using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Models
{
    public class BettingAccount
    {
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        public User? User { get; set; }

        [Required]
        [MaxLength(30)]
        public string AccountNumber { get; set; } = "";

        [Precision(18, 2)]
        public decimal Balance { get; set; }

        [Required]
        [MaxLength(20)]
        public string Status { get; set; } = "Open";

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        public List<BetTransaction> BetTransactions { get; set; } = new List<BetTransaction>();
    }
}