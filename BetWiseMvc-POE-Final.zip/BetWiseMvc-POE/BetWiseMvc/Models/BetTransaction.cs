using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace BetWiseMvc.Models
{
    public class BetTransaction
    {
        public int Id { get; set; }

        [Required]
        public int BettingAccountId { get; set; }

        public BettingAccount? BettingAccount { get; set; }

        [Required]
        public DateTime TransactionDate { get; set; }

        public DateTime CaptureDate { get; set; }

        [Required]
        [MaxLength(20)]
        public string TransactionType { get; set; } = "";

        [Precision(18, 2)]
        public decimal Amount { get; set; }

        [MaxLength(250)]
        public string? Description { get; set; }
    }
}