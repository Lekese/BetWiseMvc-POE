using System.ComponentModel.DataAnnotations;

namespace BetWiseMvc.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(13)]
        public string IDNumber { get; set; } = "";

        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; } = "";

        [Required]
        [MaxLength(100)]
        public string Surname { get; set; } = "";

        [EmailAddress]
        [MaxLength(150)]
        public string? Email { get; set; }

        [Phone]
        [MaxLength(20)]
        public string? PhoneNumber { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        public List<BettingAccount> BettingAccounts { get; set; } = new List<BettingAccount>();
    }
}