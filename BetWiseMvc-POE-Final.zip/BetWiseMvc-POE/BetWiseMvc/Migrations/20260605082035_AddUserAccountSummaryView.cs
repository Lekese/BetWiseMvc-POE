using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BetWiseMvc.Migrations
{
    /// <inheritdoc />
    public partial class AddUserAccountSummaryView : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE VIEW dbo.vw_UserAccountSummary AS
                SELECT
                    u.Id AS UserId,
                    u.IDNumber,
                    u.FirstName,
                    u.Surname,
                    u.Email,
                    u.PhoneNumber,
                    COUNT(a.Id) AS AccountCount,
                    SUM(CASE WHEN a.Status = 'Open' THEN 1 ELSE 0 END) AS OpenAccountCount,
                    SUM(CASE WHEN a.Status = 'Closed' THEN 1 ELSE 0 END) AS ClosedAccountCount,
                    COALESCE(SUM(a.Balance), 0) AS TotalBalance,
                    STRING_AGG(a.AccountNumber, ', ') AS AccountNumbers
                FROM dbo.Users u
                LEFT JOIN dbo.BettingAccounts a
                    ON u.Id = a.UserId
                GROUP BY
                    u.Id,
                    u.IDNumber,
                    u.FirstName,
                    u.Surname,
                    u.Email,
                    u.PhoneNumber;
            ");

            migrationBuilder.CreateIndex(
                name: "IX_BetTransactions_TransactionDate",
                table: "BetTransactions",
                column: "TransactionDate");

            migrationBuilder.CreateIndex(
                name: "IX_BettingAccounts_Status",
                table: "BettingAccounts",
                column: "Status");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_BetTransactions_TransactionDate",
                table: "BetTransactions");

            migrationBuilder.DropIndex(
                name: "IX_BettingAccounts_Status",
                table: "BettingAccounts");

            migrationBuilder.Sql("DROP VIEW IF EXISTS dbo.vw_UserAccountSummary;");
        }
    }
}