using System.ComponentModel.DataAnnotations;

namespace BetWiseMvc.ViewModels
{
    public class BetTransactionDto
    {
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Transaction Date")]
        public DateTime TransactionDate { get; set; } = DateTime.Today;

        [Required]
        [RegularExpression("^(Debit|Credit)$", ErrorMessage = "Select Debit or Credit.")]
        [Display(Name = "Transaction Type")]
        public string TransactionType { get; set; } = "";

        [Required]
        [Range(typeof(decimal), "0.01", "9999999999999999.99", ErrorMessage = "Amount must be greater than zero.")]
        [Display(Name = "Amount")]
        public decimal Amount { get; set; }

        [MaxLength(250)]
        public string? Description { get; set; }
    }
}
