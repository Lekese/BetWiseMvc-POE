using BetWiseMvc.Models;

namespace BetWiseMvc.ViewModels
{
    public class UserListViewModel
    {
        public List<User> Users { get; set; } = new List<User>();

        public string Search { get; set; } = "";

        public int PageIndex { get; set; }

        public int TotalPages { get; set; }
    }
}