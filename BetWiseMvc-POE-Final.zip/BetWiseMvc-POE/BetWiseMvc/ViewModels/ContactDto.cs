using System.ComponentModel.DataAnnotations;

namespace BetWiseMvc.ViewModels
{
    public class ContactDto
    {
        [Required]
        [MaxLength(100)]
        public string FullName { get; set; } = "";

        [Required]
        [EmailAddress]
        [MaxLength(150)]
        public string Email { get; set; } = "";

        [Required]
        [MaxLength(100)]
        public string Subject { get; set; } = "";

        [Required]
        [MaxLength(1000)]
        public string Message { get; set; } = "";
    }
}