using System.ComponentModel.DataAnnotations;

namespace BetWiseMvc.ViewModels
{
    public class UserDto
    {
        [Required]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "ID Number must contain exactly 13 digits.")]
        [RegularExpression(@"^\d{13}$", ErrorMessage = "ID Number must contain exactly 13 digits.")]
        [Display(Name = "ID Number")]
        public string IDNumber { get; set; } = "";

        [Required]
        [MaxLength(100)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = "";

        [Required]
        [MaxLength(100)]
        public string Surname { get; set; } = "";

        [EmailAddress]
        [MaxLength(150)]
        public string? Email { get; set; }

        [Phone]
        [MaxLength(20)]
        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }
    }
}
