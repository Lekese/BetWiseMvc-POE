using System.ComponentModel.DataAnnotations;

namespace BetWiseMvc.ViewModels
{
    public class AccountDto
    {
        [Required]
        [StringLength(30, MinimumLength = 4, ErrorMessage = "Account Number must contain between 4 and 30 characters.")]
        [Display(Name = "Account Number")]
        public string AccountNumber { get; set; } = "";
    }
}
