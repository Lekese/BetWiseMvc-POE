using BetWiseMvc.Models;
using BetWiseMvc.Services;
using Microsoft.AspNetCore.Mvc;

namespace BetWiseMvc.Controllers
{
    public class ReportsController : Controller
    {
        private readonly ReportService reportService;

        public ReportsController(ReportService reportService)
        {
            this.reportService = reportService;
        }

        public IActionResult Index(string? search)
        {
            List<UserAccountSummary> summaries = reportService.GetUserAccountSummaries(search);
            ViewData["Search"] = search ?? "";

            return View(summaries);
        }
    }
}
