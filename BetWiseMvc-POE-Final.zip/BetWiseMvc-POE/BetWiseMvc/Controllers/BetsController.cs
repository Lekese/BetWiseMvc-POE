using BetWiseMvc.Models;
using BetWiseMvc.Services;
using BetWiseMvc.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BetWiseMvc.Controllers
{
    public class BetsController : Controller
    {
        private readonly BetService betService;

        public BetsController(BetService betService)
        {
            this.betService = betService;
        }

        public IActionResult Create(int accountId)
        {
            BettingAccount? account = betService.GetAccountById(accountId);

            if (account == null)
            {
                return RedirectToAction("Index", "Users");
            }

            if (account.Status == "Closed")
            {
                TempData["ErrorMessage"] = "No transactions may be posted to a closed account.";
                return RedirectToAction("Details", "Accounts", new { id = accountId });
            }

            ViewData["AccountId"] = account.Id;
            ViewData["AccountNumber"] = account.AccountNumber;
            ViewData["Balance"] = account.Balance;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int accountId, BetTransactionDto transactionDto)
        {
            BettingAccount? account = betService.GetAccountById(accountId);

            if (account == null)
            {
                return RedirectToAction("Index", "Users");
            }

            ViewData["AccountId"] = account.Id;
            ViewData["AccountNumber"] = account.AccountNumber;
            ViewData["Balance"] = account.Balance;

            if (!ModelState.IsValid)
            {
                return View(transactionDto);
            }

            string errorMessage = betService.CreateTransaction(accountId, transactionDto);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(transactionDto);
            }

            return RedirectToAction("Details", "Accounts", new { id = accountId });
        }

        public IActionResult Edit(int id)
        {
            BetTransaction? transaction = betService.GetTransactionById(id);

            if (transaction == null || transaction.BettingAccount == null)
            {
                return RedirectToAction("Index", "Users");
            }

            if (transaction.BettingAccount.Status == "Closed")
            {
                TempData["ErrorMessage"] = "Transactions cannot be edited on a closed account.";
                return RedirectToAction("Details", "Accounts", new { id = transaction.BettingAccountId });
            }

            BetTransactionDto transactionDto = betService.ConvertToDto(transaction);

            ViewData["TransactionId"] = transaction.Id;
            ViewData["AccountId"] = transaction.BettingAccountId;
            ViewData["AccountNumber"] = transaction.BettingAccount.AccountNumber;
            ViewData["Balance"] = transaction.BettingAccount.Balance;
            ViewData["CaptureDate"] = transaction.CaptureDate;

            return View(transactionDto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, BetTransactionDto transactionDto)
        {
            BetTransaction? transaction = betService.GetTransactionById(id);

            if (transaction == null || transaction.BettingAccount == null)
            {
                return RedirectToAction("Index", "Users");
            }

            ViewData["TransactionId"] = transaction.Id;
            ViewData["AccountId"] = transaction.BettingAccountId;
            ViewData["AccountNumber"] = transaction.BettingAccount.AccountNumber;
            ViewData["Balance"] = transaction.BettingAccount.Balance;
            ViewData["CaptureDate"] = transaction.CaptureDate;

            if (!ModelState.IsValid)
            {
                return View(transactionDto);
            }

            string errorMessage = betService.UpdateTransaction(id, transactionDto);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(transactionDto);
            }

            return RedirectToAction("Details", "Accounts", new { id = transaction.BettingAccountId });
        }
    }
}