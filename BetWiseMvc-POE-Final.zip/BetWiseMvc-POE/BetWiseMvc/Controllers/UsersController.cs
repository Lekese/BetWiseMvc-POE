using BetWiseMvc.Models;
using BetWiseMvc.Services;
using BetWiseMvc.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BetWiseMvc.Controllers
{
    public class UsersController : Controller
    {
        private readonly UserService userService;

        public UsersController(UserService userService)
        {
            this.userService = userService;
        }

        public IActionResult Index(string? search, int pageIndex = 1)
        {
            UserListViewModel model = userService.GetUsers(search, pageIndex);
            return View(model);
        }

        public IActionResult Details(int id)
        {
            User? user = userService.GetUserById(id);

            if (user == null)
            {
                return RedirectToAction("Index");
            }

            return View(user);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(UserDto userDto)
        {
            if (!ModelState.IsValid)
            {
                return View(userDto);
            }

            string errorMessage = userService.CreateUser(userDto);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(userDto);
            }

            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            User? user = userService.GetUserById(id);

            if (user == null)
            {
                return RedirectToAction("Index");
            }

            UserDto userDto = userService.ConvertToDto(user);

            ViewData["UserId"] = id;

            return View(userDto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, UserDto userDto)
        {
            if (!ModelState.IsValid)
            {
                ViewData["UserId"] = id;
                return View(userDto);
            }

            string errorMessage = userService.UpdateUser(id, userDto);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                ViewData["UserId"] = id;
                ModelState.AddModelError("", errorMessage);
                return View(userDto);
            }

            return RedirectToAction("Details", new { id = id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            string errorMessage = userService.DeleteUser(id);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                TempData["ErrorMessage"] = errorMessage;
            }

            if (string.IsNullOrWhiteSpace(errorMessage))
            {
                TempData["SuccessMessage"] = "User deleted successfully.";
            }

            return RedirectToAction("Index");
        }
    }
}