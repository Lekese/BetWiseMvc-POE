using BetWiseMvc.Models;
using BetWiseMvc.Services;
using BetWiseMvc.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BetWiseMvc.Controllers
{
    public class AccountsController : Controller
    {
        private readonly AccountService accountService;

        public AccountsController(AccountService accountService)
        {
            this.accountService = accountService;
        }

        public IActionResult Details(int id)
        {
            BettingAccount? account = accountService.GetAccountById(id);

            if (account == null)
            {
                return RedirectToAction("Index", "Users");
            }

            account.BetTransactions = account.BetTransactions
                .OrderByDescending(t => t.TransactionDate)
                .ToList();

            return View(account);
        }

        public IActionResult Create(int userId)
        {
            User? user = accountService.GetUserById(userId);

            if (user == null)
            {
                return RedirectToAction("Index", "Users");
            }

            ViewData["UserId"] = userId;
            ViewData["UserName"] = user.FirstName + " " + user.Surname;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int userId, AccountDto accountDto)
        {
            User? user = accountService.GetUserById(userId);

            if (user == null)
            {
                return RedirectToAction("Index", "Users");
            }

            ViewData["UserId"] = userId;
            ViewData["UserName"] = user.FirstName + " " + user.Surname;

            if (!ModelState.IsValid)
            {
                return View(accountDto);
            }

            string errorMessage = accountService.CreateAccount(userId, accountDto);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(accountDto);
            }

            return RedirectToAction("Details", "Users", new { id = userId });
        }

        public IActionResult Edit(int id)
        {
            BettingAccount? account = accountService.GetAccountById(id);

            if (account == null)
            {
                return RedirectToAction("Index", "Users");
            }

            AccountDto accountDto = accountService.ConvertToDto(account);

            ViewData["AccountId"] = account.Id;
            ViewData["UserId"] = account.UserId;
            ViewData["Balance"] = account.Balance;
            ViewData["Status"] = account.Status;

            return View(accountDto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, AccountDto accountDto)
        {
            BettingAccount? account = accountService.GetAccountById(id);

            if (account == null)
            {
                return RedirectToAction("Index", "Users");
            }

            ViewData["AccountId"] = account.Id;
            ViewData["UserId"] = account.UserId;
            ViewData["Balance"] = account.Balance;
            ViewData["Status"] = account.Status;

            if (!ModelState.IsValid)
            {
                return View(accountDto);
            }

            string errorMessage = accountService.UpdateAccount(id, accountDto);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(accountDto);
            }

            return RedirectToAction("Details", new { id = id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Close(int id)
        {
            string errorMessage = accountService.CloseAccount(id);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                TempData["ErrorMessage"] = errorMessage;
            }
            else
            {
                TempData["SuccessMessage"] = "Account closed successfully.";
            }

            return RedirectToAction("Details", new { id = id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reopen(int id)
        {
            string errorMessage = accountService.ReopenAccount(id);

            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                TempData["ErrorMessage"] = errorMessage;
            }
            else
            {
                TempData["SuccessMessage"] = "Account reopened successfully.";
            }

            return RedirectToAction("Details", new { id = id });
        }
    }
}